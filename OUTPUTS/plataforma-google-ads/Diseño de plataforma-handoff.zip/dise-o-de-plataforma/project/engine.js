/* engine.js — lógica de negocio para la Plataforma de Google Ads.
   Puerto a JS de analysis.py / negative_keywords.py / copy_generator.py.
   Sin dependencias de UI — solo transforma datos. */

// ---------------------------------------------------------------------------
// Utilidades generales
// ---------------------------------------------------------------------------

export function detectDelimiter(sampleLine) {
  const counts = {
    ",": (sampleLine.match(/,/g) || []).length,
    "\t": (sampleLine.match(/\t/g) || []).length,
    ";": (sampleLine.match(/;/g) || []).length,
  };
  return Object.entries(counts).sort((a, b) => b[1] - a[1])[0][0];
}

export function parseDelimited(text, delimiter) {
  // Parser simple con soporte de comillas dobles.
  const lines = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n");
  const rows = [];
  for (const line of lines) {
    if (line === "") continue;
    const cells = [];
    let cur = "";
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (inQuotes) {
        if (ch === '"') {
          if (line[i + 1] === '"') { cur += '"'; i++; }
          else inQuotes = false;
        } else cur += ch;
      } else {
        if (ch === '"') inQuotes = true;
        else if (ch === delimiter) { cells.push(cur); cur = ""; }
        else cur += ch;
      }
    }
    cells.push(cur);
    rows.push(cells);
  }
  return rows;
}

export function textToTable(text) {
  const firstLine = text.split(/\r?\n/).find((l) => l.trim() !== "") || "";
  const delimiter = detectDelimiter(firstLine);
  const rows = parseDelimited(text, delimiter);
  if (rows.length === 0) return { headers: [], records: [] };
  const headers = rows[0].map((h) => h.trim());
  const records = rows.slice(1).map((r) => {
    const obj = {};
    headers.forEach((h, i) => { obj[h] = r[i] !== undefined ? r[i] : ""; });
    return obj;
  });
  return { headers, records };
}

export function toNumber(raw) {
  if (raw === null || raw === undefined) return NaN;
  if (typeof raw === "number") return raw;
  const cleaned = String(raw).replace(/%/g, "").replace(/\$/g, "").replace(/,/g, "").trim();
  if (cleaned === "" || cleaned === "--") return NaN;
  const n = parseFloat(cleaned);
  return Number.isNaN(n) ? NaN : n;
}

function findColumn(headers, candidates) {
  for (const c of candidates) if (headers.includes(c)) return c;
  return null;
}

export function downloadCsv(filename, rows) {
  const csv = rows.map((r) => r.map((v) => {
    const s = String(v ?? "");
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  }).join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

// ---------------------------------------------------------------------------
// Función 1 — Análisis de rendimiento
// ---------------------------------------------------------------------------

const COLUMN_ALIASES = {
  campaign: ["Campaign", "Campaña"],
  status: ["Campaign status", "Estado de la campaña"],
  budget: ["Budget", "Presupuesto"],
  impressions: ["Impr.", "Impressions", "Impr"],
  clicks: ["Clicks", "Clics"],
  ctr: ["CTR"],
  avg_cpc: ["Avg. CPC", "CPC prom.", "CPC promedio"],
  cost: ["Cost", "Costo"],
  conversions: ["Conversions", "Conversiones"],
  cost_per_conv: ["Cost / conv.", "Costo/conv.", "Costo / conv."],
  conv_rate: ["Conv. rate", "Tasa de conv."],
  lost_is_budget: ["Search Lost IS (budget)", "IS perdido por presupuesto (búsqueda)", "Search lost IS (budget)"],
  lost_is_rank: ["Search Lost IS (rank)", "IS perdido por ranking (búsqueda)", "Search lost IS (rank)"],
  campaign_type: ["Campaign type", "Tipo de campaña"],
};

export const CTR_THRESHOLDS_BY_TYPE = {
  search_brand: 0.20,
  search_generic: 0.08,
  display: 0.01,
  performance_max: 0.03,
};
export const DEFAULT_CAMPAIGN_TYPE = "search_generic";

export const CAMPAIGN_TYPE_LABELS = {
  search_brand: "Search (marca)",
  search_generic: "Search (genérica)",
  display: "Display",
  performance_max: "Performance Max",
};

const CAMPAIGN_TYPE_ALIASES = {
  search: "search", "búsqueda": "search", busqueda: "search",
  display: "display", "red de display": "display",
  "performance max": "performance_max", "performance max campaigns": "performance_max",
  "máximo rendimiento": "performance_max", "maximo rendimiento": "performance_max",
};
const DEFAULT_BASE_TYPE = "search";

export const DEFAULT_BRAND_KEYWORDS = ["marca", "brand", "branded", "brnd"];

const THRESHOLDS = {
  cpa_high_vs_avg_pct: 0.20,
  lost_is_budget_high: 0.10,
  lost_is_rank_high: 0.10,
  min_cost_to_flag: 0.0,
};

function normalizeBaseType(raw) {
  if (raw === null || raw === undefined || raw === "") return DEFAULT_BASE_TYPE;
  const key = String(raw).trim().toLowerCase();
  return CAMPAIGN_TYPE_ALIASES[key] || DEFAULT_BASE_TYPE;
}

function refineSearchType(name, brandKeywords) {
  const lower = String(name).toLowerCase();
  if (brandKeywords.some((kw) => kw && lower.includes(kw.toLowerCase()))) return "search_brand";
  return "search_generic";
}

export function loadCampaignReport(text, brandKeywords) {
  const bk = brandKeywords && brandKeywords.length ? brandKeywords : DEFAULT_BRAND_KEYWORDS;
  const { headers, records } = textToTable(text);
  const campaignCol = findColumn(headers, COLUMN_ALIASES.campaign);
  if (!campaignCol) {
    throw new Error('No se encontró una columna de campaña reconocible. Revisa que el archivo sea un export de campañas de Google Ads.');
  }
  const filtered = records.filter((r) => {
    const v = r[campaignCol];
    return v !== undefined && v !== "" && !String(v).toLowerCase().includes("total");
  });

  const numericFields = ["budget", "impressions", "clicks", "ctr", "avg_cpc", "cost", "conversions", "cost_per_conv", "conv_rate", "lost_is_budget", "lost_is_rank"];
  const typeCol = findColumn(headers, COLUMN_ALIASES.campaign_type);
  const statusCol = findColumn(headers, COLUMN_ALIASES.status);

  const rows = filtered.map((r) => {
    const row = { campaign: String(r[campaignCol]) };
    for (const field of numericFields) {
      const col = findColumn(headers, COLUMN_ALIASES[field]);
      let v = col ? toNumber(r[col]) : NaN;
      if (["ctr", "conv_rate", "lost_is_budget", "lost_is_rank"].includes(field) && !Number.isNaN(v)) v = v / 100;
      row[field] = v;
    }
    row.status = statusCol ? String(r[statusCol]) : "N/D";
    const base = typeCol ? normalizeBaseType(r[typeCol]) : DEFAULT_BASE_TYPE;
    row.campaign_type = base === "search" ? refineSearchType(row.campaign, bk) : base;
    row.has_type_column = !!typeCol;
    return row;
  });

  return rows;
}

export function computeMetrics(rows) {
  const totalCost = rows.reduce((s, r) => s + (Number.isNaN(r.cost) ? 0 : r.cost), 0);
  return rows.map((r) => {
    const row = { ...r };
    row.cpa = !Number.isNaN(row.cost_per_conv) ? row.cost_per_conv
      : (row.conversions > 0 ? row.cost / row.conversions : NaN);
    if (Number.isNaN(row.ctr) && row.impressions > 0) row.ctr = row.clicks / row.impressions;
    row.share_of_spend = totalCost > 0 ? (Number.isNaN(row.cost) ? 0 : row.cost) / totalCost : 0;
    return row;
  });
}

export function summarize(rows) {
  const totalCost = rows.reduce((s, r) => s + (Number.isNaN(r.cost) ? 0 : r.cost), 0);
  const totalConversions = rows.reduce((s, r) => s + (Number.isNaN(r.conversions) ? 0 : r.conversions), 0);
  const avgCpaWeighted = totalConversions > 0 ? totalCost / totalConversions : null;
  const validCpa = rows.map((r) => r.cpa).filter((v) => !Number.isNaN(v));
  const avgCpaSimple = validCpa.length ? validCpa.reduce((a, b) => a + b, 0) / validCpa.length : null;
  return {
    total_cost: totalCost,
    total_conversions: totalConversions,
    avg_cpa_weighted: avgCpaWeighted,
    avg_cpa_simple: avgCpaSimple,
    campanas_analizadas: rows.length,
    campanas_con_gasto: rows.filter((r) => r.cost > 0).length,
  };
}

export function generateRecommendations(rows) {
  const recs = [];
  const validCpa = rows.map((r) => r.cpa).filter((v) => !Number.isNaN(v));
  const avgCpa = validCpa.length ? validCpa.reduce((a, b) => a + b, 0) / validCpa.length : null;

  for (const row of rows) {
    const cost = Number.isNaN(row.cost) ? 0 : row.cost;
    if (cost < THRESHOLDS.min_cost_to_flag) continue;

    if (avgCpa && !Number.isNaN(row.cpa) && row.cpa > avgCpa * (1 + THRESHOLDS.cpa_high_vs_avg_pct)) {
      const pct = (row.cpa / avgCpa - 1) * 100;
      recs.push({
        campaign: row.campaign, categoria: "CPA",
        hallazgo: `CPA de $${row.cpa.toFixed(2)} está ${pct.toFixed(0)}% por arriba del promedio de cuenta ($${avgCpa.toFixed(2)}).`,
        recomendacion: "Revisar las palabras clave/segmentos de mayor gasto de esta campaña; pausar o bajar puja en las que no conviertan.",
        impacto_gasto: row.share_of_spend,
      });
    }
    if (!Number.isNaN(row.lost_is_budget) && row.lost_is_budget > THRESHOLDS.lost_is_budget_high) {
      recs.push({
        campaign: row.campaign, categoria: "Presupuesto",
        hallazgo: `Está perdiendo ${(row.lost_is_budget * 100).toFixed(0)}% de impression share por presupuesto limitado.`,
        recomendacion: "Si el CPA es sano, subir presupuesto — se está dejando de mostrar por falta de fondos, no por relevancia.",
        impacto_gasto: row.share_of_spend,
      });
    }
    const campaignType = row.campaign_type || DEFAULT_CAMPAIGN_TYPE;
    const ctrThreshold = CTR_THRESHOLDS_BY_TYPE[campaignType] ?? CTR_THRESHOLDS_BY_TYPE[DEFAULT_CAMPAIGN_TYPE];
    const typeLabel = CAMPAIGN_TYPE_LABELS[campaignType] || campaignType;
    if (!Number.isNaN(row.ctr) && row.ctr < ctrThreshold) {
      recs.push({
        campaign: row.campaign, categoria: "Relevancia (CTR)",
        hallazgo: `CTR de ${(row.ctr * 100).toFixed(2)}%, por debajo del mínimo saludable para ${typeLabel} (${(ctrThreshold * 100).toFixed(0)}%).`,
        recomendacion: "Revisar relevancia de anuncios y palabras clave; probar nuevo copy o ajustar tipos de concordancia.",
        impacto_gasto: row.share_of_spend,
      });
    }
    if (!Number.isNaN(row.lost_is_rank) && row.lost_is_rank > THRESHOLDS.lost_is_rank_high) {
      recs.push({
        campaign: row.campaign, categoria: "Ranking / Quality Score",
        hallazgo: `Está perdiendo ${(row.lost_is_rank * 100).toFixed(0)}% de impression share por ranking (calidad o puja).`,
        recomendacion: "Revisar Quality Score a nivel keyword y considerar subir puja solo si la relevancia del anuncio ya es buena.",
        impacto_gasto: row.share_of_spend,
      });
    }
  }
  recs.sort((a, b) => b.impacto_gasto - a.impacto_gasto);
  return recs;
}

// ---------------------------------------------------------------------------
// Función 2 — Negativización de términos de búsqueda
// ---------------------------------------------------------------------------

const TERM_COLUMN_ALIASES = {
  term: ["Término de búsqueda", "Search term"],
  clicks: ["Clics", "Clicks"],
  impr: ["Impr.", "Impressions"],
  cost: ["Costo", "Cost"],
  conversions: ["Conversiones", "Conversions"],
};

function locateHeaderAndParse(text, aliasCandidates) {
  const cleanText = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  const lines = cleanText.split("\n").filter((l) => l.trim() !== "");
  if (!lines.length) return null;
  const delimiters = ["\t", ",", ";"];
  for (const delim of delimiters) {
    const rows = parseDelimited(lines.join("\n"), delim);
    for (let i = 0; i < Math.min(rows.length, 6); i++) {
      const cells = rows[i].map((c) => c.trim());
      if (aliasCandidates.some((a) => cells.includes(a))) {
        const headers = cells;
        const records = rows.slice(i + 1).map((r) => {
          const obj = {};
          headers.forEach((h, idx) => { obj[h] = r[idx] !== undefined ? r[idx] : ""; });
          return obj;
        });
        return { headers, records };
      }
    }
  }
  return null;
}

export function loadSearchTerms(text) {
  // El export nativo de "Términos de búsqueda" de Google Ads trae 2 líneas
  // de título antes del encabezado real, y puede venir en UTF-16/tabs o
  // como CSV estándar — se busca la fila de encabezado entre las primeras.
  let parsed = locateHeaderAndParse(text, TERM_COLUMN_ALIASES.term);
  if (!parsed) parsed = textToTable(text);
  const { headers, records } = parsed;
  const termCol = findColumn(headers, TERM_COLUMN_ALIASES.term);
  if (!termCol) throw new Error("No se encontró una columna de término de búsqueda reconocible.");
  const filtered = records.filter((r) => r[termCol] && !String(r[termCol]).startsWith("Total:"));
  return filtered.map((r) => {
    const row = { term: String(r[termCol]) };
    for (const field of ["clicks", "impr", "cost", "conversions"]) {
      const col = findColumn(headers, TERM_COLUMN_ALIASES[field]);
      const v = col ? toNumber(r[col]) : 0;
      row[field] = Number.isNaN(v) ? 0 : v;
    }
    return row;
  });
}

function normalizeAccents(text) {
  const accents = { "á": "a", "é": "e", "í": "i", "ó": "o", "ú": "u", "ñ": "n", "ü": "u" };
  let out = String(text).toLowerCase();
  for (const [a, b] of Object.entries(accents)) out = out.split(a).join(b);
  return out;
}

export function classifyTerms(rows, coreTerms, exceptions) {
  const coreN = (coreTerms || []).map(normalizeAccents).filter(Boolean);
  const excN = (exceptions || []).map(normalizeAccents).filter(Boolean);
  return rows.map((r) => {
    const norm = normalizeAccents(r.term);
    const matchesCore = coreN.some((c) => norm.includes(c));
    const matchesExc = excN.some((e) => norm.includes(e));
    let clasificacion = "negativizar";
    if (matchesExc && matchesCore) clasificacion = "revisar";
    else if (matchesCore) clasificacion = "mantener";
    return { ...r, clasificacion };
  });
}

export function summarizeClassification(rows) {
  const cats = ["mantener", "revisar", "negativizar"];
  const out = {};
  for (const c of cats) {
    const sub = rows.filter((r) => r.clasificacion === c);
    out[c] = {
      terminos: sub.length,
      costo: sub.reduce((s, r) => s + r.cost, 0),
      clics: sub.reduce((s, r) => s + r.clicks, 0),
    };
  }
  return out;
}

// ---------------------------------------------------------------------------
// Función 3 — Generador de copys desde URL / HTML
// ---------------------------------------------------------------------------

export const HEADLINE_LIMIT = 30;
export const DESCRIPTION_LIMIT = 90;

const OFFER_PATTERNS = [
  /\d{1,3}\s?%\s?(de\s)?(descuento|off)/i,
  /(hasta|desde)\s+\d{1,3}\s?%/i,
  /env[íi]o\s+gratis/i,
  /entrega\s+gratis/i,
  /todo\s+inclu[íi]do/i,
  /sin\s+costo/i,
  /cuotas?\s+sin\s+inter[ée]s/i,
  /garant[íi]a\s+(de\s+)?\d+\s+(d[íi]as|meses|a[ñn]os)/i,
  /\d+x\d+/i,
  /[$€]\s?\d[\d.,]*/,
  /(oferta|promoci[óo]n)\s+(especial|exclusiva|limitada)?/i,
  /reserva\s+(ya|ahora|hoy)/i,
  /[úu]ltimas?\s+unidades/i,
  /solo\s+por\s+hoy/i,
];
const GENERIC_OFFERS = ["Precios Especiales", "Oferta Disponible", "Promoción Vigente"];

const HEADLINE_TEMPLATES = [
  "{keyword}", "{keyword} Oficial", "Compra {keyword}", "{keyword} Hoy",
  "{keyword}: Oferta", "Descuento en {keyword}", "{keyword} Envío Gratis",
  "Mejor Precio: {keyword}", "{keyword} Garantizado", "Reserva {keyword}",
  "{keyword} Disponible Ya", "{brand}: {keyword}", "{keyword} - {brand}",
  "Compra Online: {keyword}", "{keyword} Sin Costo Extra", "{brand} Oficial",
  "{keyword} | Precio Especial",
];
const DESCRIPTION_TEMPLATES = [
  "Descubre {keyword}. {offer}. Compra hoy y aprovecha los mejores precios online.",
  "{keyword} al mejor precio. {offer}. Envío rápido y atención garantizada.",
  "{offer} en {keyword}. Miles de clientes satisfechos. Compra segura hoy mismo.",
  "Encuentra {keyword} con garantía. {offer}. Haz tu pedido en minutos.",
  "{brand} te ofrece {keyword}. {offer}. Calidad y confianza en cada compra.",
  "{keyword} disponible ahora. {offer}. Reserva en línea sin complicaciones.",
  "Conoce {keyword} de {brand}. {offer}. Atención personalizada todos los días.",
  "{offer} exclusiva en {keyword}. No dejes pasar esta oportunidad, compra ya.",
  "{keyword}: la opción preferida por miles. {offer}. Compra 100% segura.",
  "Todo lo que buscas en {keyword} está aquí. {offer}. Pide el tuyo hoy.",
];

function clean(text) { return String(text || "").replace(/\s+/g, " ").trim(); }

function fit(text, limit) {
  text = clean(text);
  if (text.length <= limit) return text;
  let truncated = text.slice(0, limit);
  const lastSpace = truncated.lastIndexOf(" ");
  if (lastSpace > -1) truncated = truncated.slice(0, lastSpace);
  return truncated.trim();
}

function guessBrandAndKeyword(title, h1, domain) {
  const domainRoot = domain.replace(/^www\./, "").split(".")[0].toLowerCase();
  const parts = title ? title.split(/\s*[|\-–:•]\s*/).map((p) => p.trim()).filter(Boolean) : [];
  let brand = null;
  for (const part of parts) {
    const words = (part.toLowerCase().match(/[a-záéíóúñ]+/g) || []);
    if (words.some((w) => w.length >= 4 && domainRoot.includes(w))) { brand = part; break; }
  }
  if (!brand && parts.length) brand = parts.reduce((a, b) => (b.length < a.length ? b : a));
  if (!brand) brand = domainRoot.charAt(0).toUpperCase() + domainRoot.slice(1);

  let keyword = h1 ? h1.trim() : null;
  if (!keyword && parts.length) {
    const remaining = parts.filter((p) => p !== brand);
    keyword = remaining.length ? remaining.reduce((a, b) => (b.length > a.length ? b : a)) : parts[0];
  }
  if (!keyword) keyword = brand;
  return { brand, keyword };
}

export function extractSignals(html, url) {
  const doc = new DOMParser().parseFromString(html, "text/html");
  let domain = "sitio.com";
  try { domain = new URL(url).hostname; } catch (e) { /* keep default */ }

  const title = clean(doc.title || "");
  const metaTag = doc.querySelector('meta[name="description"]');
  const metaDescription = metaTag ? clean(metaTag.getAttribute("content")) : "";
  const h1el = doc.querySelector("h1");
  const h1 = h1el ? clean(h1el.textContent) : "";
  const h2s = Array.from(doc.querySelectorAll("h2")).map((h) => clean(h.textContent)).filter(Boolean);
  const liTexts = Array.from(doc.querySelectorAll("li")).map((li) => clean(li.textContent)).filter((t) => t.length >= 3 && t.length <= 100);
  const ctaTexts = Array.from(doc.querySelectorAll("a, button")).map((t) => clean(t.textContent)).filter((t) => t.length >= 3 && t.length <= 40);

  const fullText = clean(doc.body ? doc.body.textContent : "");
  const offers = [];
  for (const pattern of OFFER_PATTERNS) {
    const re = new RegExp(pattern.source, pattern.flags.includes("g") ? pattern.flags : pattern.flags + "g");
    let m;
    while ((m = re.exec(fullText)) !== null) {
      const phrase = clean(m[0]);
      if (phrase && !offers.includes(phrase)) offers.push(phrase);
      if (!re.global) break;
    }
  }
  const finalOffers = offers.slice(0, 10).length ? offers.slice(0, 10) : GENERIC_OFFERS;

  const { brand, keyword } = guessBrandAndKeyword(title, h1, domain);

  return { title, meta_description: metaDescription, h1, h2s, li_texts: liTexts, cta_texts: ctaTexts, offers: finalOffers, brand, keyword, domain };
}

function keywordWithoutBrand(keyword, brand) {
  if (!brand || !keyword) return keyword;
  const escaped = brand.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  let stripped = keyword.replace(new RegExp(escaped, "gi"), "");
  stripped = clean(stripped.replace(/^[\s\-–:|]+|[\s\-–:|]+$/g, ""));
  return stripped.length >= 6 ? stripped : keyword;
}

export function generateHeadlines(signals, n = 15) {
  const candidates = [];
  const keywordShort = keywordWithoutBrand(signals.keyword, signals.brand);
  for (const raw of [signals.title, signals.h1, ...signals.h2s, ...signals.cta_texts]) {
    if (raw) candidates.push(fit(raw, HEADLINE_LIMIT));
  }
  for (const template of HEADLINE_TEMPLATES) {
    const usesBrand = template.includes("{brand}");
    const kw = usesBrand ? keywordShort : signals.keyword;
    const text = template.replace(/\{keyword\}/g, kw).replace(/\{brand\}/g, signals.brand);
    candidates.push(fit(text, HEADLINE_LIMIT));
  }
  const seen = new Set(); const result = [];
  for (const c of candidates) {
    const key = c.toLowerCase();
    if (c && !seen.has(key)) { seen.add(key); result.push(c); }
    if (result.length === n) break;
  }
  const fallbacks = ["Oferta Especial Hoy", "Compra Segura Online", "Envío a Todo el País", "Atención Personalizada", "Precios Increíbles", "Calidad Garantizada"];
  let i = 0;
  while (result.length < n && i < 50) {
    const extra = fit(fallbacks[i % fallbacks.length], HEADLINE_LIMIT);
    if (!seen.has(extra.toLowerCase())) { seen.add(extra.toLowerCase()); result.push(extra); }
    i++;
  }
  return result.slice(0, n);
}

export function generateDescriptions(signals, n = 10) {
  const candidates = [];
  if (signals.meta_description) candidates.push(fit(signals.meta_description, DESCRIPTION_LIMIT));
  for (const li of signals.li_texts) candidates.push(fit(li, DESCRIPTION_LIMIT));
  const keywordShort = keywordWithoutBrand(signals.keyword, signals.brand);
  DESCRIPTION_TEMPLATES.forEach((template, i) => {
    const offer = signals.offers[i % signals.offers.length];
    const usesBrand = template.includes("{brand}");
    const kw = usesBrand ? keywordShort : signals.keyword;
    const text = template.replace(/\{keyword\}/g, kw).replace(/\{brand\}/g, signals.brand).replace(/\{offer\}/g, offer);
    candidates.push(fit(text, DESCRIPTION_LIMIT));
  });
  const seen = new Set(); const result = [];
  for (const c of candidates) {
    const key = c.toLowerCase();
    if (c && c.length >= 10 && !seen.has(key)) { seen.add(key); result.push(c); }
    if (result.length === n) break;
  }
  let i = 0;
  while (result.length < n && i < 50) {
    const offer = signals.offers[i % signals.offers.length];
    const text = fit(`${keywordShort} con la confianza de ${signals.brand}. ${offer}. Compra hoy mismo, fácil y seguro.`, DESCRIPTION_LIMIT);
    if (!seen.has(text.toLowerCase())) { seen.add(text.toLowerCase()); result.push(text); }
    i++;
  }
  return result.slice(0, n);
}

// Datos de ejemplo listos para un clic — permiten demostrar cada función
// sin depender de que el usuario tenga un archivo real a la mano.
export const SAMPLE_CAMPAIGN_CSV = `Campaign,Campaign status,Budget,Impr.,Clicks,CTR,Avg. CPC,Cost,Conversions,Cost / conv.,Conv. rate,Search Lost IS (budget),Search Lost IS (rank)
Search - Marca Estelar Manzanillo,Enabled,$50.00,12000,480,4.00%,$0.35,$168.00,22,$7.64,4.58%,2.00%,3.00%
Search - Habitaciones Cartagena,Enabled,$80.00,9000,300,3.33%,$1.20,$360.00,6,$60.00,2.00%,5.00%,8.00%
Search - Genérico Hoteles Caribe,Enabled,$60.00,15000,180,1.20%,$0.90,$162.00,9,$18.00,5.00%,4.00%,6.00%
Display - Remarketing,Enabled,$30.00,200000,800,0.40%,$0.15,$120.00,15,$8.00,1.88%,0.00%,0.00%
Search - Ofertas Fin de Semana,Enabled,$40.00,8000,320,4.00%,$0.45,$144.00,18,$8.00,5.63%,22.00%,3.00%
Search - Todo Incluido,Enabled,$70.00,11000,400,3.64%,$0.60,$240.00,14,$17.14,3.50%,2.00%,25.00%
Performance Max - Reservas,Enabled,$100.00,50000,900,1.80%,$0.70,$630.00,35,$18.00,3.89%,5.00%,4.00%
Search - Competidores Brand,Enabled,$35.00,5000,150,3.00%,$1.80,$270.00,3,$90.00,2.00%,1.00%,2.00%
Search - Bodas y Eventos,Enabled,$20.00,2000,60,3.00%,$0.50,$30.00,2,$15.00,3.33%,0.00%,1.00%
Search - Corporativo,Paused,$25.00,1000,25,2.50%,$0.60,$15.00,1,$15.00,4.00%,0.00%,0.00%
Total: all campaigns,--,,313000,3615,,,"$2,139.00",125,,,,`;

export const SAMPLE_SEARCH_TERMS_CSV = `Search term,Clicks,Impr.,Cost,Conversions
estelar playa manzanillo,210,3400,240.10,18
hotel estelar manzanillo cartagena,95,1500,88.40,7
reservar estelar manzanillo,60,900,52.00,5
manzanillo del mar apartamentos,42,880,38.75,0
manzanillo del mar cartagena barrio,25,610,19.90,0
hoteles baratos cartagena,110,4200,96.30,1
todo incluido cancun,88,3100,71.20,0
vuelos economicos bogota,54,2000,44.10,0
que hacer en cartagena gratis,37,1500,28.60,0
hotel estelar,140,2600,132.90,9
booking cartagena ofertas,63,1900,55.40,0
trabajo hotel cartagena,18,700,12.30,0
estelar apartamentos amoblados bogota,22,610,17.80,0`;

// Páginas de ejemplo (idénticas en espíritu a las usadas para probar
// copy_generator.py sin salida a internet) — permiten demostrar la función
// sin depender de que el fetch a una URL real no choque con CORS.
export const DEMO_PAGES = {
  completa: {
    label: "Ejemplo: página completa (hotel todo incluido)",
    url: "https://www.hotelesestelar.com/playa-manzanillo",
    html: `<html><head><title>Hotel Estelar Playa Manzanillo | Todo Incluido Cartagena</title>
    <meta name="description" content="Reserva tu Todo Incluido en Estelar Playa Manzanillo, Cartagena. Hasta 20% de descuento reservando online."></head>
    <body>
    <h1>Todo Incluido en Playa Manzanillo</h1>
    <h2>Habitaciones frente al mar</h2>
    <h2>3 piscinas y acceso directo a la playa</h2>
    <ul>
      <li>Desayuno, almuerzo y cena incluidos</li>
      <li>Bebidas nacionales ilimitadas</li>
      <li>Wifi gratis en todo el hotel</li>
      <li>Niños hasta 12 años se hospedan gratis</li>
    </ul>
    <p>Reserva ya y aprovecha hasta 20% de descuento. Cuotas sin interés disponibles.</p>
    <a href="#">Reservar Ahora</a>
    <button>Ver Disponibilidad</button>
    </body></html>`,
  },
  minima: {
    label: "Ejemplo: página mínima (solo título)",
    url: "https://www.hotelboutiquecentro.com/",
    html: `<html><head><title>Hotel Boutique Centro</title></head><body></body></html>`,
  },
};
