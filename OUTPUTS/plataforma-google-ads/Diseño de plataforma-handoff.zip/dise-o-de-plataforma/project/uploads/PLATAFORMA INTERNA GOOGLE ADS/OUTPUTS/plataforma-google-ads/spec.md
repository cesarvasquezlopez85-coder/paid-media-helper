# Spec: Plataforma de Análisis de Google Ads — Fase 1 (Validar y calibrar)
Fecha: 2026-07-12

## Overview
La Fase 1 no agrega funcionalidades nuevas al prototipo — corrige dos puntos que hoy hacen que sus recomendaciones no sean confiables con datos reales, y valida con cuentas de verdad si reemplazan el análisis manual del estratega. El objetivo es que, al final de esta fase, cesar pueda confiar en las recomendaciones automáticas sin tener que revisar cada número a mano.

## Usuarios objetivo
cesar, quien corre la validación directamente: sube exports reales de 3-5 cuentas del equipo y compara lo que la app recomienda contra lo que él, como estratega, recomendaría manualmente. Hoy ese análisis lo hace a mano, campaña por campaña; el objetivo es que la app lo haga por él sin perder criterio.

## Alcance

### La v1 SÍ hace
- Segmenta el umbral de CTR bajo según el tipo de campaña. Search se divide en marca (20% mínimo) y genérica (8% mínimo) — quien busca el nombre de la marca casi siempre hace clic, así que un umbral único generaba falsas alertas en marca. Display 1%, Performance Max 3%. Una campaña de Search se considera de marca si su nombre contiene una palabra clave definida por cesar (por defecto: "marca", "brand", "branded", "brnd" — cubre la convención real del equipo de usar BRND/GNR o Genérica en el nombre); sin match, o si el archivo no trae la columna "Campaign type", se trata como Search genérica (el umbral más conservador, para no esconder alertas reales).
- Muestra el CPA promedio de cuenta de dos formas, claramente diferenciadas: el ponderado por gasto (gasto total / conversiones totales, el mismo que ya usa el resumen ejecutivo) y el simple entre campañas (el que ya usan las alertas de CPA alto). Ambos números se etiquetan para que no se confundan entre sí.
- Sigue permitiendo subir un CSV/Excel de campañas por vez, por cuenta, igual que hoy — sin cambios en ese flujo.

### La v1 NO hace
- No agrega persistencia ni historial entre cargas (eso es Fase 2).
- No agrega control de acceso ni login (eso es Fase 2).
- No resuelve dónde vive la app en producción — sigue corriendo local mientras se valida.
- No toca la Función 2 (negativización de términos de búsqueda) — esa función ya se construyó y se validó por separado con datos reales de la cuenta Estelar Playa Manzanillo (ver `negative_keywords.py` y `Negativos_Estelar_Playa_Manzanillo.xlsx`); esta Fase 1 es solo sobre la Función 1 (rendimiento).
- No toca la Función 3 (generador de copys desde URL) — esa función también ya se construyó (ver `copy_generator.py`) y se probó con páginas simuladas, pero todavía no con URLs reales; esta Fase 1 es solo sobre la Función 1.
- No cambia el orden de prioridad de las recomendaciones (CPA → presupuesto → CTR → ranking), solo los umbrales y la forma de calcular el CPA promedio.

## Comportamiento esperado
1. cesar sube el export real de una cuenta (CSV/Excel), igual que hoy.
2. La app calcula las métricas y, para la alerta de CTR bajo, revisa la columna "Campaign type" de cada fila para saber si es Search, Display o Performance Max (1% y 3% respectivamente para estas dos últimas). Si es Search, revisa el nombre de la campaña contra la lista de palabras de marca que cesar definió: si matchea, aplica 20%; si no, aplica 8%. Si el archivo no trae la columna "Campaign type", toda la fila se trata como Search y se decide marca/genérica solo por el nombre.
3. En el resumen ejecutivo, la app muestra el CPA promedio ponderado por gasto (como hoy) y, junto a él, el CPA promedio simple entre campañas — cada uno con su etiqueta, para que quede claro cuál es cuál.
4. La alerta de "CPA alto" sigue comparando cada campaña contra el promedio simple, ahora mostrado explícitamente junto al ponderado (no se cambia la lógica de la alerta, solo la visibilidad del número usado).
5. cesar repite este proceso con 3-5 cuentas reales del equipo y anota, campaña por campaña, si la recomendación de la app coincide con lo que él recomendaría manualmente.

## Errores y seguridad
- Archivo sin columna "Campaign type": se trata como Search, y dentro de Search se decide marca/genérica solo por el nombre — sin bloquear el análisis ni mostrar error.
- Campaña de Search cuyo nombre no matchea ninguna palabra de marca: se trata como genérica (8%), el umbral más conservador, no marca (20%) — para no esconder una alerta real detrás de un umbral alto.
- Archivo sin las columnas obligatorias ya validadas en v1 (Campaign, Cost, Conversions): sigue el mismo manejo de error que ya existe en el prototipo, sin cambios en esta fase.
- Si el archivo trae tipos de campaña no reconocidos (ej. Shopping, Video), se tratan igual que Search hasta que haya evidencia real de que necesitan su propio umbral.

## Éxito
La Fase 1 se considera lista cuando, al correr la app con 3-5 cuentas reales, las recomendaciones de la app coinciden con el criterio de cesar como estratega en la mayoría de los casos (referencia: 4 de 5 cuentas o más). Si no se llega a ese nivel, se documenta en qué casos difiere y por qué, antes de pasar a Fase 2.

## Fuera de este spec (ya resuelto o en otra fase)
- Persistencia histórica y control de acceso (Fase 2 del roadmap, no de este spec).
- Negativización de términos de búsqueda — **ya no está pendiente**: se construyó y se validó con datos reales de la cuenta Estelar Playa Manzanillo (934 términos: 96 mantener, 824 candidatos a negativo, 14 en revisión). El mecanismo compara contra términos núcleo y excepciones definidas por el usuario, no es un modelo de lenguaje por término — ver `negative_keywords.py`. Pendiente: revisar a mano los 14 términos en "revisar" antes de negativizar cualquiera en la cuenta real.
- Generador de copys desde URL (Función 3) — **se construyó** (`copy_generator.py`): pega una URL y entrega 15 títulos (≤30 caracteres) y 10 descripciones (≤90 caracteres) sin usar un modelo de lenguaje, combinando extracción real de la página con plantillas de conversión. Se probó con páginas simuladas (contenido completo y contenido mínimo), no con URLs reales — el sandbox de esta sesión no tiene salida a internet arbitraria. Pendiente: correrla con URLs reales del equipo y que un copywriter confirme si el resultado es publicable tal cual.
- Decisión de dónde vive la app en producción (Streamlit Cloud privado vs. servidor interno).
- Si con más cuentas reales aparecen otros tipos de campaña (Shopping, Video, etc.) con CTR naturalmente distinto, definir sus propios umbrales.
