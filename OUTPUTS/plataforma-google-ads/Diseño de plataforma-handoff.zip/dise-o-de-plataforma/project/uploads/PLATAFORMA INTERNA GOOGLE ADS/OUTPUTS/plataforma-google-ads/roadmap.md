# Roadmap: Plataforma de Análisis de Google Ads
Fecha: 2026-07-12

## La idea en una frase
Herramienta interna para que cualquier persona del equipo suba el export de una cuenta de Google Ads y reciba gráficas de rendimiento y recomendaciones de optimización priorizadas, sin depender de un análisis manual — pensada para cubrir 100+ cuentas de forma self-serve.

## La acción core
Subir un CSV/Excel de campañas → recibir recomendaciones priorizadas (CPA, presupuesto, relevancia, ranking) en la misma pantalla, sin intervención manual. Ya está construida en el prototipo v1; todo lo que sigue existe para que esa acción se pueda confiar y escalar a 100+ cuentas reales.

## Ya construido y validado
- **Función 1 — Análisis de rendimiento:** prototipo v1 corriendo de punta a punta con datos sintéticos. Pendiente de validar con cuentas reales (ver Fase 1).
- **Función 2 — Negativización de términos de búsqueda:** dejó de ser un experimento. Se construyó (`negative_keywords.py` + pestaña en `app.py`) y se validó con el reporte real de la cuenta Estelar Playa Manzanillo (934 términos: 96 mantener, 824 candidatos a negativo, 14 en revisión). El mecanismo **no es clasificación semántica vía modelo de lenguaje** — es comparación de texto contra "términos núcleo" y "excepciones conocidas" que el usuario define (ej. núcleo "estelar"/"manzanillo", excepción "manzanillo del mar", que resultó ser una zona real de Cartagena distinta del hotel). Es gratis e instantáneo, con el límite de que solo separa la ambigüedad que alguien anticipó como excepción — por eso nunca se auto-publica, siempre hay una categoría "revisar" antes de subir nada a Google Ads.
- **Función 3 — Generador de copys desde URL:** se construyó (`copy_generator.py` + pestaña en `app.py`). El usuario pega una URL y la plataforma entrega 15 títulos (≤30 caracteres) y 10 descripciones (≤90 caracteres) para un anuncio de búsqueda responsivo. Tampoco usa un modelo de lenguaje — extrae título, encabezados, CTAs y ofertas reales de la página y las combina con plantillas de copywriting de conversión; cada texto se valida contra el límite de caracteres antes de mostrarse. Probado con dos páginas simuladas (una con contenido completo, otra casi vacía): en ambas entregó exactamente 15/10 textos, sin exceder límites ni duplicados. **Pendiente:** no se pudo probar contra una URL real en este entorno (la red del sandbox está restringida); falta correrla con URLs reales del equipo y que un copywriter confirme si el resultado es publicable tal cual.

## Fase 1 — Lanzamiento
La app ya corre de punta a punta con datos sintéticos. Lo que falta no es construir más features — es probar que las recomendaciones aguantan datos reales antes de que el equipo confíe en ellas.

| # | Feature | Estado | Por qué va primero | Depende de |
|---|---------|--------|--------------------|------------|
| 1 | Correr v1 con 3-5 cuentas reales y comparar contra el criterio de un estratega humano | **Pendiente** | Es la única forma de saber si el análisis automático reemplaza el trabajo manual, o si los umbrales están mal calibrados | — |
| 2 | Segmentar el umbral de CTR por tipo de campaña: Search marca 20%, Search genérica 8%, Display 1%, Performance Max 3% (sin columna "Campaign type", o tipo no reconocido, se trata como Search; dentro de Search, marca se detecta por el nombre de la campaña — palabras clave configurables, por defecto "marca"/"brand"/"branded"/"brnd", cubriendo la convención real del equipo BRND/GNR) | **Construido** (`analysis.py` + `app.py`) | La prueba con datos sintéticos mostró una alerta cuestionable en Performance Max con el umbral único de v1; y por separado, cesar confirmó que Search de marca necesita su propio umbral (20%) porque el CTR de marca es naturalmente muy alto — un umbral único para todo Search también generaba ruido | #1 |
| 3 | Mostrar el "CPA promedio de cuenta" en dos versiones diferenciadas: ponderado por gasto y simple entre campañas (la alerta de CPA alto usa el simple) | **Construido** (`analysis.py` + `app.py`) | Dos números distintos para la misma cuenta rompe la confianza del equipo en la herramienta desde el primer uso; ahora se muestran ambos, etiquetados, en vez de unificarlos en uno solo | #1 |

**Nota de verificación pendiente:** el `sample_data.csv` de prueba no trae la columna real "Campaign type" de Google Ads, así que campañas nombradas "Display - ..." o "Performance Max - ..." (solo en el texto del nombre, no en una columna de tipo) caen en Search genérica por el fallback definido — comportamiento esperado con este archivo, pero hay que confirmar con un export real de Google Ads que sí incluya esa columna al correr la Fase 1.

## Fase 2 — Mejora
Con las cuentas reales validadas, esto es lo que hace falta para que 100+ personas usen la misma herramienta sin fricción — el despliegue (dónde vive la app) no es prioridad todavía, así que no bloquea esta fase.

| # | Feature | Por qué |
|---|---------|---------|
| 1 | Persistencia histórica (base de datos ligera) | Prioridad definida: guardar el resumen de cada carga por cuenta y fecha habilita ver tendencia, no solo la foto del momento — hoy cada análisis se pierde al cerrar la sesión |
| 2 | Validar que el archivo subido es reciente y de la cuenta correcta | Hoy la plataforma no detecta si alguien sube el archivo equivocado; con más gente usándola, ese error se vuelve más probable |
| 3 | Control de acceso básico | Necesario antes de exponer la herramienta a 100+ personas, pero solo importa una vez que ya hay algo que proteger (los datos históricos de la Fase 2.1) |

## Backlog
- **Revisar a mano los 14 términos "revisar" y los términos que solo contienen "estelar"** (cadena con varias propiedades en Colombia — un núcleo tan amplio puede retener búsquedas de otro hotel Estelar) antes de subir cualquier negativo real de Estelar Playa Manzanillo a Google Ads.
- **Probar la Función 3 con 5-10 URLs reales de distintos clientes** y que un copywriter del equipo revise si el copy generado es publicable tal cual o necesita ajuste — define si el mecanismo de reglas alcanza o si vale la pena el costo de un modelo de lenguaje solo para esta función.
- **Guardar términos núcleo/excepciones por cuenta**, para no reescribirlos cada semana — depende de la persistencia de Fase 2.
- **Clasificación semántica o generación de copy vía modelo de lenguaje (v2.1 / v3.1).** Solo evaluar si el mecanismo de reglas de la Función 2 o la Función 3 resulta insuficiente en la práctica — hoy no hay evidencia de que haga falta en ninguna de las dos.
- **Validar las políticas de contenido de Google Ads en el copy generado por la Función 3** (mayúsculas, superlativos, marcas de terceros) — hoy solo se valida longitud de caracteres, no política.
- **Decidir dónde vive la app (Streamlit Cloud privado vs. servidor interno).** No es prioridad mientras se valida con cuentas reales corriendo local.
- **Integración directa con la API de Google Ads (v2+).** Solo tiene sentido si subir archivos de 100+ cuentas a mano se vuelve un cuello de botella operativo real — no hay evidencia de eso todavía.

## Siguiente paso
La Fase 1 ya tiene spec (`spec.md`). Ejecutarla: correr la Función 1 con 3-5 cuentas reales del equipo. En paralelo: revisar a mano la lista "revisar" de la Función 2 antes de negativizar nada en la cuenta de Estelar Playa Manzanillo, y probar la Función 3 con URLs reales para validar la calidad del copy fuera del entorno de pruebas.
