# Plataforma de Análisis de Google Ads — Resumen del proyecto

## Qué es

Una herramienta interna para que cualquier persona del equipo suba archivos de una cuenta de Google Ads, o pegue una URL, y reciba sin intervención manual: (1) gráficas de rendimiento y recomendaciones de optimización, (2) una lista de candidatos a palabra clave negativa, y (3) copys de anuncio (títulos y descripciones) para un anuncio de búsqueda responsivo. Pensada para cubrir 100+ cuentas de forma self-serve.

## Estado: tres funciones construidas y validadas

### Función 1 — Análisis de rendimiento

Sube un CSV/Excel de campañas → calcula CPA, CTR, share de gasto e impression share perdido, genera gráficas y recomendaciones priorizadas por gasto. Probado con datos sintéticos de 10 campañas.

Umbral de CTR segmentado por tipo de campaña (Fase 1, ya construido): Search se divide en marca (20% mínimo) y genérica (8% mínimo) — quien busca el nombre de la marca casi siempre hace clic, así que un umbral único generaba falsas alertas en marca. Display 1%, Performance Max 3%. Marca se detecta por palabras clave en el nombre de la campaña, configurables por el usuario (por defecto: "marca", "brand", "branded", "brnd" — cubre la convención BRND/GNR del equipo); sin match, o sin la columna "Campaign type" en el archivo, se trata como Search genérica.

El resumen ejecutivo ahora muestra el CPA promedio de cuenta en dos versiones diferenciadas: ponderado por gasto y simple entre campañas (este último es el que usa la alerta de "CPA alto"), para que no se confundan como un solo número.

### Función 2 — Negativización de términos de búsqueda

Sube el reporte de términos de búsqueda → el usuario define términos núcleo y excepciones conocidas → la plataforma clasifica cada término en Mantener / Revisar / Candidato a negativo.

Se validó con el reporte real de la cuenta Estelar Playa Manzanillo (934 términos, 12 de julio de 2026):

| Categoría | Términos | Costo | Clics |
|---|---|---|---|
| Mantener | 96 | $674.47 | 629 |
| Revisar (ambiguos) | 14 | $5.83 | 8 |
| Candidatos a negativo | 824 | $121.43 | 151 |

El caso que validó el mecanismo: "Manzanillo del Mar" es una zona real de Cartagena distinta de la playa donde está el hotel. Un match de texto simple habría mantenido esos 14 términos por error; con la excepción configurada, quedaron separados en "revisar" para que alguien decida.

### Función 3 — Generador de copys desde URL

Pegas la URL de una página → la plataforma descarga el HTML, extrae señales de conversión (título, H1/H2, meta description, textos de botones, ofertas mencionadas, marca) y genera 15 títulos (≤30 caracteres) y 10 descripciones (≤90 caracteres) para un anuncio de búsqueda responsivo, listos para descargar en CSV.

Se probó con una página ficticia de hotel todo-incluido (con título, meta description, encabezados, lista de amenidades, CTAs y menciones de descuento) y con una página mínima (solo un `<title>`, sin nada más). En ambos casos entregó exactamente 15 títulos y 10 descripciones, ninguno excede su límite de caracteres, sin duplicados.

## Por qué ninguna de las tres funciones usa un modelo de lenguaje por análisis

A 100+ cuentas, llamar a una API por cada archivo o URL tiene costo y latencia reales, y en el caso de negativización y copys implicaría que cada persona del equipo tenga su propia clave de API. Por eso la Función 2 compara contra términos núcleo/excepciones definidas por el usuario, y la Función 3 combina extracción real de la página con plantillas de copywriting de conversión. El costo de esta decisión: ninguna de las dos "entiende" el contenido como lo haría un modelo — solo detectan lo que ya se les definió o lo que literalmente está escrito en la página. Por eso ambas funciones piden revisión humana antes de publicar nada.

## Limitaciones conocidas

- El `sample_data.csv` de prueba no trae la columna real "Campaign type" de Google Ads, así que en ese archivo las campañas de Display/Performance Max caen por defecto en Search genérica — hay que confirmar con un export real que sí incluya esa columna.
- Las palabras de marca (Función 1) y los términos núcleo/excepciones (Función 2) se escriben en la pantalla cada vez que se sube un archivo — no se guardan por cuenta todavía (depende de la persistencia de Fase 2).
- "Estelar" como término núcleo (Función 2) es amplio — es una cadena con varias propiedades en Colombia, puede retener búsquedas de otro hotel Estelar.
- La Función 3 no ejecuta JavaScript: páginas que cargan su contenido dinámicamente van a dar poco texto real y el resultado se apoya más en plantillas genéricas.
- La Función 3 no valida las políticas de contenido de Google Ads (mayúsculas, superlativos, marcas de terceros) — solo longitud de caracteres.
- Ninguna de las tres funciones valida que el archivo/URL subido sea reciente ni de la cuenta correcta.
- No hay persistencia entre cargas ni control de acceso todavía (backlog v1.1).

## Próximos pasos

1. Correr la Función 1 con 3-5 cuentas reales del equipo (con export real, incluyendo la columna "Campaign type") y comparar las recomendaciones contra el criterio de cesar como estratega.
2. Revisar a mano los 14 términos en "revisar" y los que solo contienen "estelar" antes de subir cualquier negativo real a la cuenta.
3. Probar la Función 3 con 5-10 URLs reales de distintos clientes y que un copywriter revise si el resultado es publicable tal cual — esto define si el mecanismo de reglas alcanza o si vale la pena el costo de un modelo de lenguaje para esta función en particular.
4. Decidir dónde va a vivir la app para que el equipo la use sin depender de una máquina local.

## Archivos del proyecto

| Archivo | Para qué sirve |
|---|---|
| `Especificacion_v1_Plataforma_Google_Ads.docx` | Especificación completa de las tres funciones: alcance, formato de archivo, mecanismo, arquitectura, riesgos |
| `app.py` | Interfaz Streamlit con las tres funciones (correr con `streamlit run app.py`) |
| `analysis.py` | Lógica de la Función 1 (rendimiento), reusable sin la interfaz |
| `negative_keywords.py` | Lógica de la Función 2 (negativización), reusable sin la interfaz |
| `copy_generator.py` | Lógica de la Función 3 (copys desde URL), reusable sin la interfaz |
| `sample_data.csv` | Datos de ejemplo para probar la Función 1 |
| `Negativos_Estelar_Playa_Manzanillo.xlsx` | Resultado real de la Función 2 para esa cuenta, listo para revisión |
| `requirements.txt` | Dependencias (`pip install -r requirements.txt`) |
| `Resumen_Proyecto.md` | Este resumen |
