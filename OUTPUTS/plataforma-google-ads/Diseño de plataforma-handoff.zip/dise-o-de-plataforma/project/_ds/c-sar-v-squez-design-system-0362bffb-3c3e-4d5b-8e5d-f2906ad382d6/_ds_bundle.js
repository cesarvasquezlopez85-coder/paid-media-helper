/* @ds-bundle: {"format":4,"namespace":"CSarVSquezDesignSystem_0362bf","components":[{"name":"FeatureCard","sourcePath":"components/cards/FeatureCard.jsx"},{"name":"ServiceCard","sourcePath":"components/cards/ServiceCard.jsx"},{"name":"StatItem","sourcePath":"components/cards/StatItem.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Eyebrow","sourcePath":"components/core/Eyebrow.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"IconTile","sourcePath":"components/core/IconTile.jsx"},{"name":"NavBar","sourcePath":"components/navigation/NavBar.jsx"}],"sourceHashes":{"components/cards/FeatureCard.jsx":"d5fed31927a4","components/cards/ServiceCard.jsx":"d1fb9f9b0f4d","components/cards/StatItem.jsx":"3202229a39d7","components/core/Button.jsx":"96ae0f3bd0c0","components/core/Eyebrow.jsx":"eae4a7d98ee8","components/core/Icon.jsx":"fb42903603b8","components/core/IconTile.jsx":"e3dbe023bb96","components/navigation/NavBar.jsx":"d8122105dac2","ui_kits/website/CtaBand.jsx":"78210157091d","ui_kits/website/Hero.jsx":"49eb478e69bd","ui_kits/website/Services.jsx":"cb67e07f1d60","ui_kits/website/TopBar.jsx":"337ad86e5a21"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.CSarVSquezDesignSystem_0362bf = window.CSarVSquezDesignSystem_0362bf || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/cards/StatItem.jsx
try { (() => {
function StatItem(props) {
  const {
    value,
    label,
    style
  } = props;
  return React.createElement('div', {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)',
      ...style
    }
  }, React.createElement('span', {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--weight-extrabold)',
      fontSize: 'var(--text-stat)',
      color: 'var(--color-accent)',
      lineHeight: 1
    }
  }, value), React.createElement('span', {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-sm)',
      lineHeight: 'var(--leading-normal)',
      color: 'var(--color-text-inverse-muted)',
      maxWidth: 220
    }
  }, label));
}
Object.assign(__ds_scope, { StatItem });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/StatItem.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
const buttonBaseStyle = {
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  gap: 8,
  fontFamily: 'var(--font-body)',
  fontWeight: 'var(--weight-semibold)',
  fontSize: 'var(--text-sm)',
  borderRadius: 'var(--radius-sm)',
  border: '1px solid transparent',
  cursor: 'pointer',
  textDecoration: 'none',
  transition: 'background-color 120ms ease, border-color 120ms ease, opacity 120ms ease',
  whiteSpace: 'nowrap'
};
const buttonSizeStyles = {
  sm: {
    padding: '8px 14px',
    fontSize: 'var(--text-xs)'
  },
  md: {
    padding: '11px 20px',
    fontSize: 'var(--text-sm)'
  },
  lg: {
    padding: '14px 26px',
    fontSize: 'var(--text-md)'
  }
};
const buttonVariantStyles = {
  primary: {
    background: 'var(--color-button-primary-bg)',
    color: 'var(--color-button-primary-text)',
    borderColor: 'var(--color-button-primary-bg)'
  },
  accent: {
    background: 'var(--color-button-accent-bg)',
    color: 'var(--color-button-accent-text)',
    borderColor: 'var(--color-button-accent-bg)'
  },
  outline: {
    background: 'var(--color-bg-page)',
    color: 'var(--color-text-heading)',
    borderColor: 'var(--color-text-heading)'
  },
  ghost: {
    background: 'transparent',
    color: 'var(--color-accent-strong)',
    borderColor: 'transparent',
    padding: '0'
  }
};
function Button(props) {
  const {
    children,
    variant = 'primary',
    size = 'md',
    disabled = false,
    as = 'button',
    href,
    onClick,
    style,
    ...rest
  } = props;
  const merged = {
    ...buttonBaseStyle,
    ...(variant === 'ghost' ? {} : buttonSizeStyles[size]),
    ...buttonVariantStyles[variant],
    opacity: disabled ? 0.5 : 1,
    pointerEvents: disabled ? 'none' : 'auto',
    ...style
  };
  const Tag = href ? 'a' : as;
  return React.createElement(Tag, {
    href,
    onClick,
    disabled,
    style: merged,
    ...rest
  }, children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Eyebrow.jsx
try { (() => {
function Eyebrow(props) {
  const {
    children,
    align = 'left',
    underline = false,
    style
  } = props;
  return React.createElement('div', {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: align === 'center' ? 'center' : 'flex-start',
      gap: 10,
      ...style
    }
  }, React.createElement('span', {
    style: {
      fontFamily: 'var(--font-body)',
      fontWeight: 'var(--weight-semibold)',
      fontSize: 'var(--text-eyebrow)',
      letterSpacing: 'var(--tracking-eyebrow)',
      textTransform: 'uppercase',
      color: 'var(--color-accent-strong)'
    }
  }, children), underline && React.createElement('span', {
    style: {
      display: 'block',
      width: 40,
      height: 3,
      borderRadius: 'var(--radius-pill)',
      background: 'var(--color-accent)'
    }
  }));
}
Object.assign(__ds_scope, { Eyebrow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Eyebrow.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function Icon(props) {
  const {
    name,
    size = 20,
    color = 'currentColor',
    strokeWidth = 2,
    style
  } = props;
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (!ref.current) return;
    ref.current.innerHTML = '';
    if (!window.lucide) return;
    const el = document.createElement('i');
    el.setAttribute('data-lucide', name);
    ref.current.appendChild(el);
    window.lucide.createIcons({
      nodes: [el],
      attrs: {
        width: size,
        height: size,
        color: color,
        'stroke-width': strokeWidth
      }
    });
  }, [name, size, color, strokeWidth]);
  return React.createElement('span', {
    ref,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: size,
      height: size,
      ...style
    }
  });
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/IconTile.jsx
try { (() => {
const tileToneStyles = {
  dark: {
    background: 'var(--navy-950)',
    color: 'var(--color-accent)'
  },
  gold: {
    background: 'var(--color-accent)',
    color: 'var(--navy-900)'
  },
  outline: {
    background: 'transparent',
    border: '1px solid rgba(255,255,255,0.35)',
    color: 'inherit'
  }
};
function IconTile(props) {
  const {
    name,
    tone = 'dark',
    size = 40,
    iconSize,
    style
  } = props;
  const resolvedIconSize = iconSize || Math.round(size * 0.5);
  return React.createElement('div', {
    style: {
      width: size,
      height: size,
      borderRadius: 'var(--radius-sm)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexShrink: 0,
      ...tileToneStyles[tone],
      ...style
    }
  }, React.createElement(__ds_scope.Icon, {
    name,
    size: resolvedIconSize,
    color: 'currentColor'
  }));
}
Object.assign(__ds_scope, { IconTile });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconTile.jsx", error: String((e && e.message) || e) }); }

// components/cards/FeatureCard.jsx
try { (() => {
const toneBackgrounds = {
  navy: 'var(--navy-950)',
  'navy-gradient': 'linear-gradient(160deg, var(--navy-700) 0%, var(--navy-900) 100%)',
  charcoal: 'var(--charcoal-900)'
};
function FeatureCard(props) {
  const {
    icon,
    title,
    children,
    tone = 'navy',
    link,
    pill,
    style
  } = props;
  return React.createElement('div', {
    style: {
      background: toneBackgrounds[tone],
      borderRadius: 'var(--radius-md)',
      padding: 'var(--space-6)',
      minHeight: 220,
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'space-between',
      gap: 'var(--space-6)',
      boxShadow: 'var(--shadow-dark-card)',
      color: 'var(--color-text-inverse)',
      position: 'relative',
      overflow: 'hidden',
      ...style
    }
  }, icon && React.createElement(__ds_scope.IconTile, {
    name: icon,
    tone: 'outline',
    size: 44,
    iconSize: 22
  }), (title || children) && React.createElement('div', {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)'
    }
  }, title && React.createElement('h3', {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--weight-semibold)',
      fontSize: 'var(--text-h3)',
      margin: 0,
      color: 'var(--color-text-inverse)'
    }
  }, title), children && React.createElement('p', {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-sm)',
      lineHeight: 'var(--leading-normal)',
      color: 'var(--color-text-inverse-muted)',
      margin: 0
    }
  }, children), link && React.createElement('a', {
    href: link.href || '#',
    style: {
      marginTop: 'var(--space-2)',
      fontSize: 'var(--text-sm)',
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--color-accent)',
      textDecoration: 'none'
    }
  }, link.label)), pill && React.createElement('div', {
    style: {
      alignSelf: 'flex-start',
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      background: 'rgba(255,255,255,0.06)',
      border: '1px solid rgba(255,255,255,0.12)',
      borderRadius: 'var(--radius-sm)',
      padding: '10px 14px',
      fontSize: 'var(--text-xs)',
      fontWeight: 'var(--weight-medium)',
      color: 'var(--color-text-inverse)'
    }
  }, pill.icon && React.createElement(__ds_scope.IconTile, {
    name: pill.icon,
    tone: 'gold',
    size: 22,
    iconSize: 12
  }), pill.label));
}
Object.assign(__ds_scope, { FeatureCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/FeatureCard.jsx", error: String((e && e.message) || e) }); }

// components/cards/ServiceCard.jsx
try { (() => {
function ServiceCard(props) {
  const {
    icon,
    index,
    title,
    children,
    style
  } = props;
  return React.createElement('div', {
    style: {
      background: 'var(--color-bg-page)',
      border: '1px solid var(--color-border)',
      borderRadius: 'var(--radius-md)',
      padding: 'var(--space-6)',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-3)',
      boxShadow: 'var(--shadow-card)',
      transition: 'box-shadow 150ms ease, transform 150ms ease',
      ...style
    }
  }, React.createElement(__ds_scope.IconTile, {
    name: icon,
    tone: 'dark',
    size: 40
  }), index && React.createElement('span', {
    style: {
      fontSize: 'var(--text-xs)',
      fontWeight: 'var(--weight-bold)',
      color: 'var(--color-accent-strong)',
      marginTop: 4
    }
  }, index), title && React.createElement('h4', {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--weight-semibold)',
      fontSize: 'var(--text-lg)',
      color: 'var(--color-text-heading)',
      margin: 0
    }
  }, title), children && React.createElement('p', {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-sm)',
      lineHeight: 'var(--leading-normal)',
      color: 'var(--color-text-body)',
      margin: 0
    }
  }, children));
}
Object.assign(__ds_scope, { ServiceCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/ServiceCard.jsx", error: String((e && e.message) || e) }); }

// components/navigation/NavBar.jsx
try { (() => {
function NavBar(props) {
  const {
    brand = 'César Vásquez',
    tagline = 'Paid Media para Hoteles',
    links = [],
    ctaLabel = 'WhatsApp',
    style
  } = props;
  return React.createElement('div', {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '18px var(--container-pad)',
      borderBottom: '1px solid var(--color-border)',
      background: 'var(--color-bg-page)',
      fontFamily: 'var(--font-body)',
      ...style
    }
  }, React.createElement('div', {
    style: {
      display: 'flex',
      flexDirection: 'column',
      lineHeight: 1.2
    }
  }, React.createElement('span', {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--weight-bold)',
      fontSize: 'var(--text-md)',
      color: 'var(--color-text-heading)'
    }
  }, brand), React.createElement('span', {
    style: {
      fontSize: '11px',
      color: 'var(--color-text-muted)'
    }
  }, tagline)), React.createElement('nav', {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-8)'
    }
  }, links.map(l => React.createElement('a', {
    key: l.label,
    href: l.href || '#',
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--color-text-heading)',
      textDecoration: 'none',
      fontWeight: 'var(--weight-medium)'
    }
  }, l.label)), React.createElement(__ds_scope.Icon, {
    name: 'link',
    size: 18,
    color: 'var(--color-text-heading)'
  }), React.createElement(__ds_scope.Button, {
    variant: 'outline',
    size: 'sm'
  }, ctaLabel)));
}
Object.assign(__ds_scope, { NavBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/NavBar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/CtaBand.jsx
try { (() => {
function CtaBand() {
  return React.createElement('section', {
    style: {
      background: 'var(--color-bg-dark)',
      padding: '64px var(--container-pad)'
    }
  }, React.createElement('div', {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto'
    }
  }, React.createElement('div', {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      marginBottom: 48
    }
  }, React.createElement(window.__ds.IconTile, {
    name: 'check',
    tone: 'gold',
    size: 44
  }), React.createElement('h2', {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--weight-bold)',
      fontSize: 'var(--text-h2)',
      color: 'var(--color-text-inverse)',
      margin: 0,
      lineHeight: 'var(--leading-tight)'
    }
  }, 'Hacer lo correcto para tu hotel, de la forma correcta.')), React.createElement('div', {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: 24
    }
  }, React.createElement(window.__ds.StatItem, {
    value: '0%',
    label: 'de comisión en cada reserva directa que generamos'
  }), React.createElement(window.__ds.StatItem, {
    value: '100%',
    label: 'del tiempo enfocado en hotelería, cero plantillas genéricas'
  }), React.createElement(window.__ds.StatItem, {
    value: '4',
    label: 'etapas claras: diagnóstico, estrategia, lanzamiento y optimización'
  }), React.createElement(window.__ds.StatItem, {
    value: '1',
    label: 'solo interlocutor — hablas directo conmigo, no con un call center'
  }))));
}
window.CtaBand = CtaBand;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/CtaBand.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Hero.jsx
try { (() => {
function Hero() {
  return React.createElement('section', {
    style: {
      padding: '72px var(--container-pad) 56px',
      maxWidth: 'var(--container-max)',
      margin: '0 auto'
    }
  }, React.createElement(window.__ds.Eyebrow, {}, 'Consultoría en paid media · sector hotelero'), React.createElement('h1', {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--weight-extrabold)',
      fontSize: 'var(--text-h1)',
      lineHeight: 'var(--leading-tight)',
      color: 'var(--color-text-heading)',
      margin: '16px 0 20px',
      maxWidth: 640
    }
  }, 'Menos comisión para las OTAs. ', React.createElement('span', {
    style: {
      color: 'var(--color-accent-strong)'
    }
  }, 'Más reservas directas'), ' para tu hotel.'), React.createElement('p', {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-md)',
      lineHeight: 'var(--leading-normal)',
      color: 'var(--color-text-body)',
      maxWidth: 520,
      margin: '0 0 40px'
    }
  }, 'Estrategia y gestión de pauta digital (Google Ads, GA4 e IA aplicada) diseñada para hoteles independientes y cadenas hoteleras.'), React.createElement('div', {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 1fr)',
      gap: 16
    }
  }, React.createElement(window.__ds.FeatureCard, {
    icon: 'trending-up',
    tone: 'navy',
    title: 'Por qué paid media hotelero',
    link: {
      label: 'Ver servicios →'
    }
  }, 'Trabajo y experiencia en el sector por más de 10 años, así que cada campaña ya nace entendiendo ADR, ABV, temporadas, mercados y motor de reservas.'), React.createElement(window.__ds.FeatureCard, {
    icon: 'home',
    tone: 'navy-gradient',
    pill: {
      icon: 'check',
      label: 'Auditoría de tu motor de reservas'
    }
  }), React.createElement(window.__ds.FeatureCard, {
    icon: 'bar-chart-2',
    tone: 'charcoal',
    pill: {
      label: 'Decisiones basadas en datos, no en corazonadas'
    }
  })));
}
window.Hero = Hero;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Hero.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Services.jsx
try { (() => {
const SERVICES = [{
  icon: 'trending-up',
  index: '01',
  title: 'Estrategia Paid Media',
  body: 'Defino el rumbo de tu inversión publicitaria enfocado en reservas y leads, no solo en clics.'
}, {
  icon: 'search',
  index: '02',
  title: 'Google Ads & Performance Max',
  body: 'Campañas de búsqueda y Performance Max para aparecer justo cuando alguien decide dónde quedarse.'
}, {
  icon: 'send',
  index: '03',
  title: 'Campañas de marca',
  body: 'Presencia constante para que tu hotel sea la primera opción cuando alguien piense en tu destino.'
}, {
  icon: 'refresh-cw',
  index: '04',
  title: 'Remarketing',
  body: 'Vuelvo a mostrar tu propiedad a quien visitó tu web y no reservó, antes de que reserve en una OTA.'
}, {
  icon: 'bar-chart-2',
  index: '05',
  title: 'GA4 y Google Tag Manager',
  body: 'Configuro el seguimiento correcto de conversiones para saber qué campaña trae reservas reales.'
}, {
  icon: 'monitor',
  index: '06',
  title: 'Dashboards ejecutivos',
  body: 'Reportes claros que muestran el estado de tu inversión sin necesidad de abrir Google Ads.'
}];
function Services() {
  return React.createElement('section', {
    style: {
      background: 'var(--color-bg-section-alt)',
      padding: '72px var(--container-pad)'
    }
  }, React.createElement('div', {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto'
    }
  }, React.createElement('div', {
    style: {
      textAlign: 'center',
      marginBottom: 48
    }
  }, React.createElement(window.__ds.Eyebrow, {
    align: 'center'
  }, 'Lo que hago en tu cuenta'), React.createElement('h2', {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--weight-bold)',
      fontSize: 'var(--text-h2)',
      color: 'var(--color-text-heading)',
      margin: '10px 0 16px'
    }
  }, 'Servicios'), React.createElement('div', {
    style: {
      width: 40,
      height: 3,
      borderRadius: 'var(--radius-pill)',
      background: 'var(--color-accent)',
      margin: '0 auto 20px'
    }
  }), React.createElement('p', {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-base)',
      color: 'var(--color-text-body)',
      maxWidth: 520,
      margin: '0 auto',
      lineHeight: 'var(--leading-normal)'
    }
  }, 'Cada frente cubre una parte distinta del camino entre "alguien busca hotel" y "reserva confirmada en tu web".')), React.createElement('div', {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 1fr)',
      gap: 16
    }
  }, SERVICES.map(s => React.createElement(window.__ds.ServiceCard, {
    key: s.index,
    icon: s.icon,
    index: s.index,
    title: s.title
  }, s.body)))));
}
window.Services = Services;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Services.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/TopBar.jsx
try { (() => {
function TopBar(props) {
  const {
    onCta
  } = props;
  return React.createElement('div', {
    style: {
      background: 'var(--color-accent)',
      padding: '10px var(--container-pad)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 16,
      flexWrap: 'wrap'
    }
  }, React.createElement('span', {
    style: {
      fontFamily: 'var(--font-body)',
      fontWeight: 'var(--weight-semibold)',
      fontSize: 'var(--text-sm)',
      color: 'var(--navy-900)'
    }
  }, '¿Tu hotel depende demasiado de Booking y Expedia?'), React.createElement(window.__ds.Button, {
    variant: 'primary',
    size: 'sm',
    onClick: onCta
  }, 'Cotizar por WhatsApp'));
}
window.TopBar = TopBar;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/TopBar.jsx", error: String((e && e.message) || e) }); }

__ds_ns.FeatureCard = __ds_scope.FeatureCard;

__ds_ns.ServiceCard = __ds_scope.ServiceCard;

__ds_ns.StatItem = __ds_scope.StatItem;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Eyebrow = __ds_scope.Eyebrow;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.IconTile = __ds_scope.IconTile;

__ds_ns.NavBar = __ds_scope.NavBar;

})();
