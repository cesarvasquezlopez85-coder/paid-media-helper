# César Vásquez — Design System

## Context

**César Vásquez** is a solo paid-media consultant serving independent hotels and hotel chains ("Paid Media para Hoteles"). The pitch: reduce commission paid to OTAs (Booking, Expedia) by driving more direct bookings through paid search/performance media (Google Ads, Performance Max, GA4, applied AI). One product surface exists in the source material: the **marketing / landing website**.

### Source material

- `uploads/source-screenshot.png` — a single full-page screenshot of the live landing page (hero, "why paid media hotelero" feature row, 6-item services grid, closing stats band). This is the **only** source provided — no Figma file, no codebase, no additional pages or slide decks were attached.
- No logo file, icon asset pack, or webfont files were provided.

Because the only input is one static screenshot, this system was built as a from-scratch, screenshot-derived brand kit (colors sampled directly from pixel data; layout, spacing and copy read off the image). See **Caveats** below for what that means for fidelity.

## Index

- `styles.css` — root stylesheet, imports every token file. Link this one file.
- `tokens/` — `colors.css`, `typography.css`, `spacing.css` (spacing, radius, shadow).
- `components/core/` — `Button`, `Eyebrow`, `Icon`, `IconTile`.
- `components/cards/` — `FeatureCard`, `ServiceCard`, `StatItem`.
- `components/navigation/` — `NavBar`.
- `ui_kits/website/` — interactive recreation of the landing page (`index.html`, `TopBar.jsx`, `Hero.jsx`, `Services.jsx`, `CtaBand.jsx`).
- `guidelines/` — foundation specimen cards (colors, type, spacing, radius, shadow, brand/wordmark).
- `SKILL.md` — portable skill file for use in Claude Code.

## Components

| Component | Where | What |
|---|---|---|
| `Button` | core | primary/accent/outline/ghost CTA button |
| `Eyebrow` | core | small-caps gold label above headings, optional centered underline |
| `Icon` | core | single Lucide glyph (CDN) |
| `IconTile` | core | rounded icon swatch (dark/gold/outline tones) |
| `FeatureCard` | cards | dark editorial card (navy / navy-gradient / charcoal tones) used in the hero row |
| `ServiceCard` | cards | white bordered card with numbered icon service |
| `StatItem` | cards | big gold stat number + label, used in the dark CTA band |
| `NavBar` | navigation | site header — wordmark, links, LinkedIn glyph, WhatsApp CTA |

No component inventory source (Figma/codebase) was attached, so this is an intentionally small, from-scratch set sized to exactly what the one landing page needs — not a full standard library. Add primitives (Input, Select, Tabs, Dialog…) only once a real product surface needs them.

### Intentional additions
- `Icon` / `IconTile` — thin wrappers so every card/button can reference a consistent glyph system; the source has no equivalent "component," just inline icons.

## Content fundamentals

- **Language & person:** Spanish (Latin America / neutral), second-person informal "tú" throughout — "tu hotel", "diseñada para hoteles independientes", "hablas directo conmigo, no con un call center." Direct address to the hotel owner/GM, never third person.
- **Tone:** confident, plain-spoken, consultative — not hypey. Short declarative sentences. No exclamation points, no emoji anywhere in the copy.
- **Headline pattern:** contrast/reframe structure — "Menos comisión para las OTAs. **Más reservas directas** para tu hotel." States the cost of the status quo, then the gain, with the gain highlighted in gold.
- **Micro-copy is specific, not generic:** "entendiendo ADR, ABV, temporadas, mercados y motor de reservas" — uses real hotel-revenue-management vocabulary (ADR, ABV) rather than vague marketing-speak. This specificity signals category expertise.
- **Section eyebrows** are always uppercase, short, gold, and frame the section as an outcome: "CONSULTORÍA EN PAID MEDIA · SECTOR HOTELERO", "LO QUE HAGO EN TU CUENTA".
- **Numbers do the trust-building:** the stats band ("0%", "100%", "4", "1") states differentiators as blunt facts, not superlatives — no "the best," no "#1."
- **CTAs are channel-specific and low-friction:** "Cotizar por WhatsApp" — routes to a real chat, not a generic contact form. Reinforces the "one person, no call center" positioning.
- **No emoji, no jargon-stacking, no buzzwords** ("synergy", "unlock", "leverage" have no Spanish equivalents here) — copy stays literal and outcome-focused.

## Visual foundations

- **Color:** one warm gold accent (`--gold-500` / `--gold-600`) against a navy-and-charcoal dark neutral family, on a white/light-gray page. No secondary brand hue — gold carries every emphasis: eyebrows, the one highlighted headline phrase, icons-on-dark, stat numbers, CTA buttons. This is a two-color brand (navy + gold), not a multi-color palette.
- **Type:** a bold, tight geometric-grotesk for display/headings paired with a plain grotesk for body/UI — see Caveats, both are Google Fonts substitutions (Plus Jakarta Sans / Inter), not verified exact matches. Headings are semibold–extrabold with tight (1.1–1.2) line-height; body is regular weight, generous (1.6) line-height, restrained size (15–16px).
- **Spacing:** generous section padding (~64–72px vertical), a 4px base unit, cards use ~24px internal padding. Section rhythm alternates white → light-gray → dark, roughly one background change per major section — never more than 2–3 background tones per page.
- **Backgrounds:** flat colors only — no photography, no hand-drawn illustration, no repeating pattern/texture. The one "image-like" moment is a subtle diagonal linear-gradient on the middle hero card (navy-700 → navy-900); every other surface is a flat fill. No full-bleed imagery anywhere in the source.
- **Animation:** none observed (static screenshot) — treat as a static, confident brand with no motion signature; add restrained fades/transitions only if asked.
- **Hover/press states:** not visible in a static screenshot — default assumption used in components: subtle darken/opacity shift on hover, no transform/scale (matches the brand's non-flashy tone). Revisit once real interaction states are available.
- **Borders:** hairline 1px light-gray borders on white service cards; no border on dark cards (they rely on fill + shadow for separation).
- **Shadows:** soft, low-contrast drop shadows on light cards (`--shadow-card`); dark feature cards use a deeper, more diffuse shadow (`--shadow-dark-card`) to lift off the page. No inner shadows, no neumorphism.
- **Corner radii:** consistently rounded but not pill-shaped for cards/buttons (~6–14px); a true pill radius only appears on the small gold underline rule beneath centered section headers.
- **Cards:** two families — light service cards (white fill, hairline border, soft shadow, icon tile + numeral + title + one-line body) and dark feature cards (solid or gradient fill, no border, deeper shadow, icon + optional pill/link). No left-border-accent card pattern anywhere.
- **Transparency/blur:** none observed — no glassmorphism, no backdrop blur.
- **Imagery color vibe:** N/A — no photography in the source at all.
- **Layout:** centered container (~1152px max width), consistent left-aligned copy blocks in the hero, centered copy blocks for the services section header. No sticky/fixed chrome beyond a simple top nav.

## Iconography

- **System:** simple thin-stroke line icons (2px stroke, rounded caps/joins) — visually a near-exact match to [Lucide](https://lucide.dev). No icon font or SVG sprite was provided in source, so Lucide is used as a **CDN substitution** (`<script src="https://unpkg.com/lucide@latest">`), loaded by every card/kit that uses the `Icon`/`IconTile` components. **Flagged substitution — if the original site uses a different/custom icon set, please share it and this will be swapped in.**
- Icons found in source: chart/trending-line, magnifying glass, paper-plane/send, refresh/cycle, bar chart, monitor/screen, house/home, checkmark, LinkedIn glyph. All mapped 1:1 to Lucide names (`trending-up`, `search`, `send`, `refresh-cw`, `bar-chart-2`, `monitor`, `home`, `check`); the LinkedIn glyph uses a generic `link` icon since the CDN Lucide build ships no brand/social glyphs.
- No emoji, no unicode-character icons, no PNG icons observed or used.
- Icons always sit inside a small rounded dark tile (`IconTile`, navy-950 fill, gold glyph) — this tile is itself a core brand motif, repeated on both light and dark cards.

## Assets

- `assets/` contains no logo file — **none was provided.** Per design-system policy, no logo was invented or drawn. Every place a mark would go instead renders the plain-type wordmark "César Vásquez" (Plus Jakarta Sans Bold) + tagline "Paid Media para Hoteles" — see `guidelines/brand-wordmark.card.html` and the `NavBar` component.
- No background images, illustrations, or photography exist in the source; none were added.

## Caveats — please help me iterate

1. **Fonts are a guess.** The headline/body typefaces could not be identified with certainty from a screenshot. I substituted the closest Google Fonts match — **Plus Jakarta Sans** (display) + **Inter** (body) — loaded via `tokens/typography.css`. If you have the real webfont files (or know the actual family names), send them and I'll swap `@font-face` in directly.
2. **Icons are a CDN substitution** ([Lucide](https://lucide.dev)), chosen for stroke-weight/style match to the screenshot. If the real site uses a different icon set or custom SVGs, share them and I'll replace the substitution.
3. **Single source, single page.** Everything here — tokens, spacing, hover/press states, animation — is inferred from one static screenshot of the homepage. There's no way to verify interaction states, other pages/sections (Planes, Proceso), or responsive/mobile behavior without more source material (more screenshots, the live URL, or a codebase/Figma link).
4. **No component library or codebase was attached**, so the component set above is an intentionally small, from-scratch set sized to this one page — not a comprehensive UI kit. Tell me what else exists (a booking widget? a case-study page? an email template?) and I'll build it properly.

**Ask:** please attach the live site URL, a Figma file, or the codebase if any of these exist — that will let me replace every flagged substitution above with the real thing and verify hover/press/responsive behavior instead of inferring it.
